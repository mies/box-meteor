exports.die = function (msg) {
  console.error(msg);
  process.exit(1);
};
