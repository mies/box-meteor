if (typeof Meetup === 'undefined') {
  Meetup = {};
}
