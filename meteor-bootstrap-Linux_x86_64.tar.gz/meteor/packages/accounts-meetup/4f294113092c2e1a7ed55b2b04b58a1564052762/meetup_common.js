if (!Accounts.meetup) {
  Accounts.meetup = {};
}
