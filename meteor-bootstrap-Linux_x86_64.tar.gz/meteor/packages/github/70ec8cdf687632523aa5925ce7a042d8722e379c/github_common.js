if (typeof Github === 'undefined') {
  Github = {};
}
