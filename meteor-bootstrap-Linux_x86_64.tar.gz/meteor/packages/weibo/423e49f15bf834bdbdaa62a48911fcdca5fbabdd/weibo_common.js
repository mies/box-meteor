if (typeof Weibo === 'undefined') {
  Weibo = {};
}
