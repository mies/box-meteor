if (!Accounts.weibo) {
  Accounts.weibo = {};
}
