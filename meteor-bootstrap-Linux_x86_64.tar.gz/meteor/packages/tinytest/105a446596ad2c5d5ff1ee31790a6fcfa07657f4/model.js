Meteor._ServerTestResultsSubscription = 'tinytest_results_subscription';
Meteor._ServerTestResultsCollection = 'tinytest_results_collection';
