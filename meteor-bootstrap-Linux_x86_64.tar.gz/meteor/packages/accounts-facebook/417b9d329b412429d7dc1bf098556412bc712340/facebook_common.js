if (!Accounts.facebook) {
  Accounts.facebook = {};
}
