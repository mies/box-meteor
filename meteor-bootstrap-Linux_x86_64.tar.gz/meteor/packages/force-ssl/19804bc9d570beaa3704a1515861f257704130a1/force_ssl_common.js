_.extend(Meteor.absoluteUrl.defaultOptions, {secure: true});
